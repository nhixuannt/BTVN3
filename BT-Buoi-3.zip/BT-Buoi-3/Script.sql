﻿
INSERT INTO NhanVien (MaNV, TenNV, GioiTinh, DiaChi, DienThoai) VALUES
('NV001', 'Nguyen Van A', '1', '123 Nguyen Trai, Hanoi', '0912345678'),
('NV002', 'Tran Thi B', '0', '456 Le Loi, Ho Chi Minh', '0987654321'),
('NV003', 'Le Van C', '1', '789 Tran Hung Dao, Da Nang', '0901122334'),
('NV004', 'Pham Thi D', '0', '321 Phan Chu Trinh, Can Tho', '0932112233'),
('NV005', 'Hoang Van E', '1', '654 Nguyen Hue, Hue', '0977888899'),
('NV006', 'Vo Thi F', '0', '987 Le Thanh Ton, Haiphong', '0955667788'),
('NV007', 'Phan Van G', '1', '159 Tran Phu, Bien Hoa', '0966445566'),
('NV008', 'Do Thi H', '0', '753 Ly Thuong Kiet, Nha Trang', '0933667799'),
('NV009', 'Ngo Van I', '1', '852 Ba Trieu, Quy Nhon', '0911223344'),
('NV010', 'Dang Thi J', '0', '951 Nguyen Dinh Chieu, Vinh', '0922445566');


INSERT INTO KhachHang (MaKH, TenKH, DiaChi, DienThoai) VALUES
('KH001', 'Nguyen Thi Lan', '12 Le Loi, Ha Noi', '0912345678'),
('KH002', 'Tran Van Binh', '45 Tran Hung Dao, Ho Chi Minh', '0987654321'),
('KH003', 'Le Thi Hoa', '78 Nguyen Trai, Da Nang', '0901122334'),
('KH004', 'Pham Van Long', '23 Ly Thuong Kiet, Hai Phong', '0932112233'),
('KH005', 'Vo Thi Minh', '89 Quang Trung, Hue', '0977888899'),
('KH006', 'Do Van Hieu', '34 Phan Dinh Phung, Can Tho', '0955667788'),
('KH007', 'Bui Thi An', '56 Nguyen Hue, Vinh', '0966445566'),
('KH008', 'Phan Van Toan', '67 Hoang Dieu, Nha Trang', '0933667799'),
('KH009', 'Ngo Thi Lien', '90 Hai Ba Trung, Da Lat', '0911223344'),
('KH010', 'Dang Van Phuc', '78 Bach Dang, Quy Nhon', '0922445566');


INSERT INTO LoaiSanPham (Maloai, TenLoai) VALUES
('LSP001', 'Đien thoai di đong'),
('LSP002', 'May tinh bang'),
('LSP003', 'Laptop'),
('LSP004', 'May tinh đe ban'),
('LSP005', 'Tivi'),
('LSP006', 'Đo gia dung'),
('LSP007', 'Thoi trang nam'),
('LSP008', 'Thoi trang nữ'),
('LSP009', 'Phu kien cong nghe'),
('LSP010', 'Thiet bi van phong');

INSERT INTO SanPham (MaSP, TenSP, DVTinh, DonGia, MaLoai) VALUES
('SP001', 'iPhone 14', 'Chiec', 25000000, 'LSP001'),
('SP002', 'Samsung Galaxy S23', 'Chiec', 23000000, 'LSP001'),
('SP003', 'iPad Pro 12.9', 'Chiec', 30000000, 'LSP002'),
('SP004', 'Samsung Galaxy Tab S8', 'Chiec', 18000000, 'LSP002'),
('SP005', 'MacBook Pro 16', 'Chiec', 55000000, 'LSP003'),
('SP006', 'Dell XPS 13', 'Chiec', 28000000, 'LSP003'),
('SP007', 'PC Gaming ASUS', 'Bo', 32000000, 'LSP004'),
('SP008', 'PC Workstation Dell', 'Bo', 45000000, 'LSP004'),
('SP009', 'Smart TV LG 55 inch', 'Chiec', 15000000, 'LSP005'),
('SP010', 'Smart TV Samsung 65 inch', 'Chiec', 20000000, 'LSP005'),
('SP011', 'May giat LG 9kg', 'Chiec', 7000000, 'LSP006'),
('SP012', 'Tu lanh Samsung 350L', 'Chiec', 12000000, 'LSP006'),
('SP013', 'Ao thun nam', 'Cai', 200000, 'LSP007'),
('SP014', 'Quan jeans nam', 'Cai', 500000, 'LSP007'),
('SP015', 'Đam du tiec nu', 'Cai', 700000, 'LSP008'),
('SP016', 'Ao khoac nu', 'Cai', 600000, 'LSP008'),
('SP017', 'Tai nghe AirPods Pro', 'Chiec', 6000000, 'LSP009'),
('SP018', 'Ban phim co Logitech', 'Chiec', 2000000, 'LSP009'),
('SP019', 'May in HP LaserJet', 'Chiec', 3500000, 'LSP010'),
('SP020', 'May chieu Sony', 'Chiec', 15000000, 'LSP010');

SET DATEFORMAT dmy;

INSERT INTO HoaDon (MaHD, MaKH, MaNV, NgayHD, NgayNhan, ThanhTien) VALUES
('HD001', 'KH001', 'NV001', '2024/10/10', '2024/12/10', 5000000),
('HD002', 'KH002', 'NV002', '2024/12/01', '2024/14/01', 7500000),
('HD003', 'KH003', 'NV003', '2024/22/05', '2024/23/05', 10000000),
('HD004', 'KH004', 'NV004', '2024/12/03', '2024/15/03', 1500000),
('HD005', 'KH005', 'NV005', '2024/17/01', '2024/20/01', 2000000),
('HD006', 'KH006', 'NV006', '2024/02/05', '2024/04/05', 3000000),
('HD007', 'KH007', 'NV007', '2024/02/10', '2024/03/10', 2500000),
('HD008', 'KH008', 'NV008', '2024/22/09', '2024/25/09', 8000000),
('HD009', 'KH009', 'NV009', '2024/18/06', '2024/20/06', 5500000),
('HD010', 'KH010', 'NV010', '2024/25/08', '2024/26/08', 4000000),
('HD011', 'KH001', 'NV001', '2024/13/01', '2024/14/01', 7500000),
('HD012', 'KH002', 'NV002', '2024/27/05', '2024/28/05', 6000000),
('HD013', 'KH003', 'NV003', '2024/23/11', '2024/24/11', 9500000),
('HD014', 'KH004', 'NV004', '2024/23/12', '2024/25/12', 1200000),
('HD015', 'KH005', 'NV005', '2024/03/04', '2024/04/04', 3400000),
('HD016', 'KH006', 'NV006', '2024/07/07', '2024/09/07', 4500000),
('HD017', 'KH007', 'NV007', '2024/03/04', '2024/05/04', 2300000),
('HD018', 'KH008', 'NV008', '2024/24/05', '2024/24/05', 7000000),
('HD019', 'KH009', 'NV009', '2024/04/10', '2024/07/10', 3200000),
('HD020', 'KH010', 'NV010', '2024/15/12', '2024/16/12', 1500000);

INSERT INTO ChiTietHoaDon (MaHD, MaSP, SoLuong, GiaBan) VALUES
('HD001', 'SP001', 2, 25000000),
('HD001', 'SP003', 1, 30000000),
('HD002', 'SP002', 1, 23000000),
('HD002', 'SP004', 2, 18000000),
('HD003', 'SP005', 1, 55000000),
('HD003', 'SP007', 1, 32000000),
('HD004', 'SP009', 2, 15000000),
('HD004', 'SP011', 1, 7000000),
('HD005', 'SP012', 1, 12000000),
('HD005', 'SP013', 3, 200000),
('HD006', 'SP015', 2, 700000),
('HD006', 'SP017', 1, 6000000),
('HD007', 'SP018', 2, 2000000),
('HD007', 'SP019', 1, 3500000),
('HD008', 'SP008', 1, 45000000),
('HD008', 'SP010', 2, 20000000),
('HD009', 'SP006', 1, 28000000),
('HD009', 'SP014', 2, 500000),
('HD010', 'SP016', 1, 600000),
('HD010', 'SP020', 1, 15000000);
