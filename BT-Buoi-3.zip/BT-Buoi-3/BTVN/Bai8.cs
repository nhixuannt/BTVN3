﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BTVN
{
    public partial class Bai8 : Form
    {
        public Bai8()
        {
            InitializeComponent();
        }

        private void Bai8_Load(object sender, EventArgs e)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

            //Các câu lệnh Query
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "SELECT * FROM SanPham ";
            cmd.CommandType = CommandType.Text;

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Lấy dữ liệu đổ về Dataset
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            //Khởi tạo dataset
            DataSet ds = new DataSet();

            //Đổ dl từ adapter vào dataset
            adapter.Fill(ds, "Sanpham");

            //Đóng kết nối
            cnn.Close();

            //Đổ dữ liệu từ Dataset vào DataGridView
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Sanpham";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            // Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

            try
            {
                // Mở kết nối
                cnn.Open();

                // Các câu lệnh
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;

                // Sử dụng parameters để tránh SQL Injection
                cmd.CommandText = "INSERT INTO SanPham (MaSP, TenSP, DVTinh, DonGia, MaLoai) VALUES (@MaSP, @TenSP, @DVTinh, @DonGia, @MaLoai)";
                cmd.Parameters.AddWithValue("@MaSP", textBox1.Text);
                cmd.Parameters.AddWithValue("@TenSP", textBox2.Text);
                cmd.Parameters.AddWithValue("@DVTinh", textBox3.Text);
                cmd.Parameters.AddWithValue("@DonGia", textBox4.Text);
                cmd.Parameters.AddWithValue("@MaLoai", comboBox1.Text);
                cmd.CommandType = CommandType.Text;

                // Thực thi lệnh
                cmd.ExecuteNonQuery();

                MessageBox.Show("Thêm thành công");

                // Tải lại dữ liệu vào DataGridView
                LoadDataIntoDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                // Đóng kết nối
                cnn.Close();
            }

        }

        private void LoadDataIntoDataGridView()
        {
            // Khởi tạo kết nối
            SqlConnection cnn = new SqlConnection(@"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True");

            try
            {
                // Mở kết nối
                cnn.Open();

                // Câu truy vấn để lấy dữ liệu
                SqlCommand cmd = new SqlCommand("SELECT * FROM SanPham", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                // Đổ dữ liệu vào DataTable
                da.Fill(dt);

                // Gán dữ liệu cho DataGridView
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                // Đóng kết nối
                cnn.Close();
            }
        }


        private void dataGridView1_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem có hàng nào được chọn không
            if (dataGridView1.SelectedRows.Count > 0) 
            {
                // Lấy giá trị từ ô đầu tiên (cột đầu tiên) của hàng đã chọn
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                comboBox1.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "UPDATE SanPham SET TenSP = @TenSP, DVTinh = @DVTinh, DonGia = @DonGia, MaLoai = @MaLoai WHERE MaSP = @MaSP";
            cmd.Parameters.AddWithValue("@MaSP", textBox1.Text);
            cmd.Parameters.AddWithValue("@TenSP", textBox2.Text);
            cmd.Parameters.AddWithValue("@DVTinh", textBox3.Text);
            cmd.Parameters.AddWithValue("@DonGia", textBox4.Text);
            cmd.Parameters.AddWithValue("@MaLoai", comboBox1.Text);
            cmd.CommandType = CommandType.Text;


            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Đóng kết nối
            cnn.Close();

            MessageBox.Show("Cập nhật thành công");

            // Tải lại dữ liệu vào DataGridView
            LoadDataIntoDataGridView();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem có hàng nào được chọn không
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Xóa từng hàng được chọn trong DataGridView
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row);
                }

                // Lệnh kết nối
                SqlConnection cnn = new SqlConnection();

                // Thông số kết nối
                cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

                try
                {
                    // Mở kết nối
                    cnn.Open();

                    // Các câu lệnh
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = cnn;

                    cmd.CommandText = "DELETE FROM SanPham WHERE MaSP = '" + textBox1.Text + @"'";
                    //cmd.Parameters.AddWithValue("@MaSP", textBox1.Text);
                    cmd.CommandType = CommandType.Text;

                    // Thực thi lệnh
                    int rowsAffected = cmd.ExecuteNonQuery();

                    // Kiểm tra xem có hàng nào bị ảnh hưởng không
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Xóa thành công trong database.");
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy sản phẩm để xóa trong database.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
                finally
                {
                    // Đóng kết nối
                    cnn.Close();
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn hàng để xóa.");
            }
        }
    }
}
