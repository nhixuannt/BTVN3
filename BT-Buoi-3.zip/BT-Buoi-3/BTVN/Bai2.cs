﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTVN
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }

        private void Bai2_Load(object sender, EventArgs e)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI; Initial Catalog = BTVNB3; Integrated Security = True";

            //Các câu lệnh Query
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "SELECT * FROM LoaiSanPham ";
            cmd.CommandType = CommandType.Text;

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Lấy dữ liệu đổ về Dataset
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            //Khởi tạo datatable
            DataTable dt = new DataTable();

            //Đỗ dữ liệu từ Data Adapter vào Data Table
            adapter.Fill(dt);

            //Đóng kết nối
            cnn.Close();

            //Đổ dữ liệu từ Dataset vào Listbox
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "TenLoai";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
