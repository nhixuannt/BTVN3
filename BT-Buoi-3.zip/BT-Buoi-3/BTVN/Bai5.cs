﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BTVN
{
    public partial class Bai5 : Form
    {
        public Bai5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

            //Các câu lệnh Query
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "SELECT SanPham.*, TenLoai FROM SanPham JOIN LoaiSanPham ON Sanpham.Maloai = LoaiSanPham.Maloai ";
            cmd.CommandType = CommandType.Text;

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Lấy dữ liệu đổ về Dataset
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            //Khởi tạo dataset
            DataSet ds = new DataSet();

            //Đổ dl từ adapter vào dataset
            adapter.Fill(ds, "Sanpham");

            //Đóng kết nối
            cnn.Close();

            string loc = comboBox1.Text;

            //Sử dụng DataView để lọc dữ liệu
            DataView dv = new DataView(ds.Tables["Sanpham"]);

            //Lọc các tên sản phẩm chứa từ khóa tìm kiếm
            dv.RowFilter = $"TenLoai LIKE '{loc}'";

            // Đổ dữ liệu đã lọc vào DataGridView
            dataGridView1.DataSource = dv;
        }

        private void Bai5_Load(object sender, EventArgs e)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI; Initial Catalog = BTVNB3; Integrated Security = True";

            //Các câu lệnh Query
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "SELECT * FROM LoaiSanPham ";
            cmd.CommandType = CommandType.Text;

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Lấy dữ liệu đổ về Dataset
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            //Khởi tạo datatable
            DataTable dt = new DataTable();

            //Đỗ dữ liệu từ Data Adapter vào Data Table
            adapter.Fill(dt);

            //Đóng kết nối
            cnn.Close();

            //Đổ dữ liệu từ Datatable vào Listbox
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "TenLoai";
        }
    }
}
