﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTVN
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Bai3_Load(object sender, EventArgs e)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

            //Các câu lệnh Query
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "SELECT * FROM SanPham ";
            cmd.CommandType = CommandType.Text;

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Lấy dữ liệu đổ về Dataset
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            //Khởi tạo dataset
            DataSet ds = new DataSet();

            //Đổ dl từ adapter vào dataset
            adapter.Fill(ds, "Sanpham");

            //Đóng kết nối
            cnn.Close();

            //Đổ dữ liệu từ Dataset vào DataGridView
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Sanpham";
        }
    }
}
