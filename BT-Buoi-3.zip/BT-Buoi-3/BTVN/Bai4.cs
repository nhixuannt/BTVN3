﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTVN
{
    public partial class Bai4 : Form
    {
        public Bai4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            //Lệnh kết nối
            SqlConnection cnn = new SqlConnection();

            //Thông số kết nối
            cnn.ConnectionString = @"Data Source = BACHTUOTDANGIU\XUANNHI;Initial Catalog=BTVNB3;Integrated Security=True";

            //Các câu lệnh Query
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;

            cmd.CommandText = "SELECT * FROM SanPham ";
            cmd.CommandType = CommandType.Text;

            //Mở kết nối
            cnn.Open();

            //Các câu lệnh
            cmd.ExecuteNonQuery();

            //Lấy dữ liệu đổ về Dataset
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            //Khởi tạo dataset
            DataSet ds = new DataSet();

            //Đổ dl từ adapter vào dataset
            adapter.Fill(ds, "Sanpham");

            //Đóng kết nối
            cnn.Close();

            string timkiem = textBox1.Text.Trim();

            //Sử dụng DataView để lọc dữ liệu
            DataView dv = new DataView(ds.Tables["Sanpham"]);

            //Lọc các tên sản phẩm chứa từ khóa tìm kiếm
            dv.RowFilter = $"TenSP LIKE '%{timkiem}%'";

            // Đổ dữ liệu đã lọc vào DataGridView
            dataGridView1.DataSource = dv;

        }

        private void Bai4_Load(object sender, EventArgs e)
        {

        }




    }
}
