# **Hệ Thống Quản Lý Điểm Sinh Viên**

## **Chức năng**

### **1. Loại tài khoản và chức năng**

#### **1.1 Tài khoản Nhân viên Quản trị**
- Thêm và quản lý thông tin sinh viên.
- Thêm và quản lý thông tin giảng viên.
- Thêm và quản lý thông tin lớp học và môn học.

#### **1.2 Tài khoản Giảng viên**
- Xem và quản lý các lớp học được phân công.
- Chấm điểm sinh viên trong các lớp tín chỉ của mình.

#### **1.3 Tài khoản Quản trị viên**
- Quản lý tất cả tài khoản người dùng, bao gồm:
  - Cấp tài khoản cho nhân viên và giảng viên.
  - Chỉnh sửa hoặc xóa tài khoản hiện có.

### **2. Tổng quan cơ sở dữ liệu**
![img](https://github.com/butxyzj2k/QLDSV_Winform/blob/main/img/dbmodel.png)

## **Tham khảo**
- [GitHub Repository](https://github.com/chitao5799/winform?tab=readme-ov-file)
- [Video Hướng Dẫn](https://www.youtube.com/watch?v=Hgs27rWhHJk&t=266s)
