﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLDSV2.DTO
{
    internal class DTOKhoa
    {
        public string MaKhoa { get; set; }
        public string TenKhoa { get; set; }
        public System.DateTime NamThanhLap { get; set; }
        public string SoDienThoai { get; set; }
    }
}
