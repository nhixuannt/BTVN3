﻿using System.Drawing;

namespace QLDSV2
{
    partial class FrmSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbTKSV = new System.Windows.Forms.GroupBox();
            this.cbbK = new System.Windows.Forms.ComboBox();
            this.btTKAll = new System.Windows.Forms.Button();
            this.btTK = new System.Windows.Forms.Button();
            this.lbTKK = new System.Windows.Forms.Label();
            this.tbTKL = new System.Windows.Forms.TextBox();
            this.lbTKML = new System.Windows.Forms.Label();
            this.tbTKT = new System.Windows.Forms.TextBox();
            this.lbTKT = new System.Windows.Forms.Label();
            this.gbTTSV = new System.Windows.Forms.GroupBox();
            this.cbbGT = new System.Windows.Forms.ComboBox();
            this.btG = new System.Windows.Forms.Button();
            this.btH = new System.Windows.Forms.Button();
            this.btS = new System.Windows.Forms.Button();
            this.btX = new System.Windows.Forms.Button();
            this.btT = new System.Windows.Forms.Button();
            this.tbLHC = new System.Windows.Forms.TextBox();
            this.lbLHC = new System.Windows.Forms.Label();
            this.tbSDT = new System.Windows.Forms.TextBox();
            this.lbSDT = new System.Windows.Forms.Label();
            this.tbDC = new System.Windows.Forms.TextBox();
            this.lbDC = new System.Windows.Forms.Label();
            this.lbGT = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.tbNS = new System.Windows.Forms.TextBox();
            this.lbNS = new System.Windows.Forms.Label();
            this.btPH = new System.Windows.Forms.Button();
            this.tbT = new System.Windows.Forms.TextBox();
            this.lbT = new System.Windows.Forms.Label();
            this.tbM = new System.Windows.Forms.TextBox();
            this.lbM = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dvgSV = new System.Windows.Forms.DataGridView();
            this.gbTKSV.SuspendLayout();
            this.gbTTSV.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgSV)).BeginInit();
            this.SuspendLayout();
            // 
            // gbTKSV
            // 
            this.gbTKSV.Controls.Add(this.cbbK);
            this.gbTKSV.Controls.Add(this.btTKAll);
            this.gbTKSV.Controls.Add(this.btTK);
            this.gbTKSV.Controls.Add(this.lbTKK);
            this.gbTKSV.Controls.Add(this.tbTKL);
            this.gbTKSV.Controls.Add(this.lbTKML);
            this.gbTKSV.Controls.Add(this.tbTKT);
            this.gbTKSV.Controls.Add(this.lbTKT);
            this.gbTKSV.Location = new System.Drawing.Point(12, 12);
            this.gbTKSV.Name = "gbTKSV";
            this.gbTKSV.Size = new System.Drawing.Size(637, 75);
            this.gbTKSV.TabIndex = 0;
            this.gbTKSV.TabStop = false;
            this.gbTKSV.Text = "Tìm kiếm sinh viên";
            // 
            // cbbK
            // 
            this.cbbK.FormattingEnabled = true;
            this.cbbK.Location = new System.Drawing.Point(328, 32);
            this.cbbK.Name = "cbbK";
            this.cbbK.Size = new System.Drawing.Size(116, 21);
            this.cbbK.TabIndex = 3;
            // 
            // btTKAll
            // 
            this.btTKAll.Location = new System.Drawing.Point(551, 31);
            this.btTKAll.Name = "btTKAll";
            this.btTKAll.Size = new System.Drawing.Size(80, 20);
            this.btTKAll.TabIndex = 5;
            this.btTKAll.Text = "Tất cả";
            this.btTKAll.UseVisualStyleBackColor = true;
            this.btTKAll.Click += new System.EventHandler(this.btTKAll_Click);
            // 
            // btTK
            // 
            this.btTK.Location = new System.Drawing.Point(465, 31);
            this.btTK.Name = "btTK";
            this.btTK.Size = new System.Drawing.Size(80, 20);
            this.btTK.TabIndex = 4;
            this.btTK.Text = "Tìm kiếm";
            this.btTK.UseVisualStyleBackColor = true;
            this.btTK.Click += new System.EventHandler(this.btTK_Click);
            // 
            // lbTKK
            // 
            this.lbTKK.Location = new System.Drawing.Point(291, 32);
            this.lbTKK.Name = "lbTKK";
            this.lbTKK.Size = new System.Drawing.Size(55, 20);
            this.lbTKK.TabIndex = 0;
            this.lbTKK.Text = "Khoa: ";
            this.lbTKK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbTKL
            // 
            this.tbTKL.Location = new System.Drawing.Point(184, 32);
            this.tbTKL.Name = "tbTKL";
            this.tbTKL.Size = new System.Drawing.Size(101, 20);
            this.tbTKL.TabIndex = 2;
            // 
            // lbTKML
            // 
            this.lbTKML.Location = new System.Drawing.Point(141, 32);
            this.lbTKML.Name = "lbTKML";
            this.lbTKML.Size = new System.Drawing.Size(49, 20);
            this.lbTKML.TabIndex = 0;
            this.lbTKML.Text = "Mã lớp: ";
            this.lbTKML.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbTKT
            // 
            this.tbTKT.Location = new System.Drawing.Point(32, 31);
            this.tbTKT.Name = "tbTKT";
            this.tbTKT.Size = new System.Drawing.Size(101, 20);
            this.tbTKT.TabIndex = 1;
            // 
            // lbTKT
            // 
            this.lbTKT.Location = new System.Drawing.Point(5, 31);
            this.lbTKT.Name = "lbTKT";
            this.lbTKT.Size = new System.Drawing.Size(49, 20);
            this.lbTKT.TabIndex = 0;
            this.lbTKT.Text = "Tên:";
            this.lbTKT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gbTTSV
            // 
            this.gbTTSV.Controls.Add(this.cbbGT);
            this.gbTTSV.Controls.Add(this.btG);
            this.gbTTSV.Controls.Add(this.btH);
            this.gbTTSV.Controls.Add(this.btS);
            this.gbTTSV.Controls.Add(this.btX);
            this.gbTTSV.Controls.Add(this.btT);
            this.gbTTSV.Controls.Add(this.tbLHC);
            this.gbTTSV.Controls.Add(this.lbLHC);
            this.gbTTSV.Controls.Add(this.tbSDT);
            this.gbTTSV.Controls.Add(this.lbSDT);
            this.gbTTSV.Controls.Add(this.tbDC);
            this.gbTTSV.Controls.Add(this.lbDC);
            this.gbTTSV.Controls.Add(this.lbGT);
            this.gbTTSV.Controls.Add(this.tbEmail);
            this.gbTTSV.Controls.Add(this.lbEmail);
            this.gbTTSV.Controls.Add(this.tbNS);
            this.gbTTSV.Controls.Add(this.lbNS);
            this.gbTTSV.Controls.Add(this.btPH);
            this.gbTTSV.Controls.Add(this.tbT);
            this.gbTTSV.Controls.Add(this.lbT);
            this.gbTTSV.Controls.Add(this.tbM);
            this.gbTTSV.Controls.Add(this.lbM);
            this.gbTTSV.Location = new System.Drawing.Point(12, 93);
            this.gbTTSV.Name = "gbTTSV";
            this.gbTTSV.Size = new System.Drawing.Size(637, 154);
            this.gbTTSV.TabIndex = 0;
            this.gbTTSV.TabStop = false;
            this.gbTTSV.Text = "Thông tin chi tiết";
            // 
            // cbbGT
            // 
            this.cbbGT.FormattingEnabled = true;
            this.cbbGT.Location = new System.Drawing.Point(85, 112);
            this.cbbGT.Name = "cbbGT";
            this.cbbGT.Size = new System.Drawing.Size(126, 21);
            this.cbbGT.TabIndex = 9;
            // 
            // btG
            // 
            this.btG.Location = new System.Drawing.Point(535, 57);
            this.btG.Name = "btG";
            this.btG.Size = new System.Drawing.Size(80, 36);
            this.btG.TabIndex = 0;
            this.btG.Text = "Ghi";
            this.btG.UseVisualStyleBackColor = true;
            this.btG.Click += new System.EventHandler(this.btG_Click);
            // 
            // btH
            // 
            this.btH.Location = new System.Drawing.Point(535, 106);
            this.btH.Name = "btH";
            this.btH.Size = new System.Drawing.Size(80, 36);
            this.btH.TabIndex = 0;
            this.btH.Text = "Hủy";
            this.btH.UseVisualStyleBackColor = true;
            this.btH.Click += new System.EventHandler(this.btH_Click);
            // 
            // btS
            // 
            this.btS.Location = new System.Drawing.Point(449, 57);
            this.btS.Name = "btS";
            this.btS.Size = new System.Drawing.Size(80, 36);
            this.btS.TabIndex = 0;
            this.btS.Text = "Sửa";
            this.btS.UseVisualStyleBackColor = true;
            this.btS.Click += new System.EventHandler(this.btS_Click);
            // 
            // btX
            // 
            this.btX.Location = new System.Drawing.Point(449, 105);
            this.btX.Name = "btX";
            this.btX.Size = new System.Drawing.Size(80, 36);
            this.btX.TabIndex = 16;
            this.btX.Text = "Xóa";
            this.btX.UseVisualStyleBackColor = true;
            this.btX.Click += new System.EventHandler(this.btX_Click);
            // 
            // btT
            // 
            this.btT.Location = new System.Drawing.Point(449, 15);
            this.btT.Name = "btT";
            this.btT.Size = new System.Drawing.Size(80, 36);
            this.btT.TabIndex = 15;
            this.btT.Text = "Thêm";
            this.btT.UseVisualStyleBackColor = true;
            this.btT.Click += new System.EventHandler(this.btT_Click);
            // 
            // tbLHC
            // 
            this.tbLHC.Location = new System.Drawing.Point(307, 114);
            this.tbLHC.Name = "tbLHC";
            this.tbLHC.Size = new System.Drawing.Size(111, 20);
            this.tbLHC.TabIndex = 13;
            // 
            // lbLHC
            // 
            this.lbLHC.Location = new System.Drawing.Point(224, 114);
            this.lbLHC.Name = "lbLHC";
            this.lbLHC.Size = new System.Drawing.Size(88, 20);
            this.lbLHC.TabIndex = 0;
            this.lbLHC.Text = "Lớp hành chính: ";
            this.lbLHC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbSDT
            // 
            this.tbSDT.Location = new System.Drawing.Point(307, 57);
            this.tbSDT.Name = "tbSDT";
            this.tbSDT.Size = new System.Drawing.Size(111, 20);
            this.tbSDT.TabIndex = 11;
            // 
            // lbSDT
            // 
            this.lbSDT.Location = new System.Drawing.Point(224, 57);
            this.lbSDT.Name = "lbSDT";
            this.lbSDT.Size = new System.Drawing.Size(77, 20);
            this.lbSDT.TabIndex = 0;
            this.lbSDT.Text = "Số điện thoại:";
            this.lbSDT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbDC
            // 
            this.tbDC.Location = new System.Drawing.Point(307, 31);
            this.tbDC.Name = "tbDC";
            this.tbDC.Size = new System.Drawing.Size(111, 20);
            this.tbDC.TabIndex = 10;
            // 
            // lbDC
            // 
            this.lbDC.Location = new System.Drawing.Point(224, 31);
            this.lbDC.Name = "lbDC";
            this.lbDC.Size = new System.Drawing.Size(77, 20);
            this.lbDC.TabIndex = 0;
            this.lbDC.Text = "Địa chỉ: ";
            this.lbDC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbGT
            // 
            this.lbGT.Location = new System.Drawing.Point(3, 114);
            this.lbGT.Name = "lbGT";
            this.lbGT.Size = new System.Drawing.Size(77, 20);
            this.lbGT.TabIndex = 0;
            this.lbGT.Text = "Giới tính";
            this.lbGT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(307, 85);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(111, 20);
            this.tbEmail.TabIndex = 12;
            // 
            // lbEmail
            // 
            this.lbEmail.Location = new System.Drawing.Point(224, 85);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(77, 20);
            this.lbEmail.TabIndex = 0;
            this.lbEmail.Text = "Email:";
            this.lbEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbNS
            // 
            this.tbNS.Location = new System.Drawing.Point(85, 85);
            this.tbNS.Name = "tbNS";
            this.tbNS.Size = new System.Drawing.Size(126, 20);
            this.tbNS.TabIndex = 8;
            // 
            // lbNS
            // 
            this.lbNS.Location = new System.Drawing.Point(3, 85);
            this.lbNS.Name = "lbNS";
            this.lbNS.Size = new System.Drawing.Size(77, 20);
            this.lbNS.TabIndex = 0;
            this.lbNS.Text = "Ngày sinh:";
            this.lbNS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btPH
            // 
            this.btPH.Location = new System.Drawing.Point(535, 16);
            this.btPH.Name = "btPH";
            this.btPH.Size = new System.Drawing.Size(80, 36);
            this.btPH.TabIndex = 0;
            this.btPH.Text = "Phục hồi";
            this.btPH.UseVisualStyleBackColor = true;
            this.btPH.Click += new System.EventHandler(this.btPH_Click);
            // 
            // tbT
            // 
            this.tbT.Location = new System.Drawing.Point(85, 57);
            this.tbT.Name = "tbT";
            this.tbT.Size = new System.Drawing.Size(126, 20);
            this.tbT.TabIndex = 7;
            // 
            // lbT
            // 
            this.lbT.Location = new System.Drawing.Point(3, 57);
            this.lbT.Name = "lbT";
            this.lbT.Size = new System.Drawing.Size(77, 20);
            this.lbT.TabIndex = 2;
            this.lbT.Text = "Tên sinh viên:";
            this.lbT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbM
            // 
            this.tbM.Location = new System.Drawing.Point(85, 32);
            this.tbM.Name = "tbM";
            this.tbM.Size = new System.Drawing.Size(126, 20);
            this.tbM.TabIndex = 6;
            // 
            // lbM
            // 
            this.lbM.Location = new System.Drawing.Point(5, 31);
            this.lbM.Name = "lbM";
            this.lbM.Size = new System.Drawing.Size(75, 20);
            this.lbM.TabIndex = 0;
            this.lbM.Text = "Mã sinh viên:";
            this.lbM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dvgSV);
            this.panel1.Location = new System.Drawing.Point(12, 253);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(637, 159);
            this.panel1.TabIndex = 0;
            // 
            // dvgSV
            // 
            this.dvgSV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dvgSV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgSV.Location = new System.Drawing.Point(3, 3);
            this.dvgSV.Name = "dvgSV";
            this.dvgSV.Size = new System.Drawing.Size(631, 153);
            this.dvgSV.TabIndex = 0;
            this.dvgSV.SelectionChanged += new System.EventHandler(this.dvgSV_SelectionChanged);
            // 
            // FrmSinhVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 424);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbTTSV);
            this.Controls.Add(this.gbTKSV);
            this.Name = "FrmSinhVien";
            this.Text = "FrmSinhVien";
            this.gbTKSV.ResumeLayout(false);
            this.gbTKSV.PerformLayout();
            this.gbTTSV.ResumeLayout(false);
            this.gbTTSV.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgSV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbTKSV;
        private System.Windows.Forms.Button btTKAll;
        private System.Windows.Forms.Button btTK;
        private System.Windows.Forms.Label lbTKK;
        private System.Windows.Forms.TextBox tbTKL;
        private System.Windows.Forms.Label lbTKML;
        private System.Windows.Forms.TextBox tbTKT;
        private System.Windows.Forms.Label lbTKT;
        private System.Windows.Forms.GroupBox gbTTSV;
        private System.Windows.Forms.Button btS;
        private System.Windows.Forms.Button btX;
        private System.Windows.Forms.Button btT;
        private System.Windows.Forms.TextBox tbLHC;
        private System.Windows.Forms.Label lbLHC;
        private System.Windows.Forms.TextBox tbSDT;
        private System.Windows.Forms.Label lbSDT;
        private System.Windows.Forms.TextBox tbDC;
        private System.Windows.Forms.Label lbDC;
        private System.Windows.Forms.Label lbGT;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox tbNS;
        private System.Windows.Forms.Label lbNS;
        private System.Windows.Forms.Button btPH;
        private System.Windows.Forms.TextBox tbT;
        private System.Windows.Forms.Label lbT;
        private System.Windows.Forms.TextBox tbM;
        private System.Windows.Forms.Label lbM;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dvgSV;
        private System.Windows.Forms.ComboBox cbbK;
        private System.Windows.Forms.Button btH;
        private System.Windows.Forms.Button btG;
        private System.Windows.Forms.ComboBox cbbGT;
    }
}