﻿using System.Drawing;
using System.Windows.Forms;

namespace QLDSV2
{
    partial class FrmQLDSV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbTND2 = new System.Windows.Forms.Label();
            this.lbTND = new System.Windows.Forms.Label();
            this.btDangXuat = new System.Windows.Forms.Button();
            this.panelQLDSV = new System.Windows.Forms.Panel();
            this.panelContentQLDSV = new System.Windows.Forms.Panel();
            this.msQT = new System.Windows.Forms.MenuStrip();
            this.msiSV = new System.Windows.Forms.ToolStripMenuItem();
            this.msiGV = new System.Windows.Forms.ToolStripMenuItem();
            this.msiLHP = new System.Windows.Forms.ToolStripMenuItem();
            this.msiLTC = new System.Windows.Forms.ToolStripMenuItem();
            this.msiMH = new System.Windows.Forms.ToolStripMenuItem();
            this.msiD = new System.Windows.Forms.ToolStripMenuItem();
            this.msiTK = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3.SuspendLayout();
            this.panelQLDSV.SuspendLayout();
            this.msQT.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.lbTND2);
            this.panel3.Controls.Add(this.lbTND);
            this.panel3.Location = new System.Drawing.Point(14, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(243, 47);
            this.panel3.TabIndex = 1;
            // 
            // lbTND2
            // 
            this.lbTND2.BackColor = System.Drawing.SystemColors.Control;
            this.lbTND2.Location = new System.Drawing.Point(97, 17);
            this.lbTND2.Name = "lbTND2";
            this.lbTND2.Size = new System.Drawing.Size(131, 17);
            this.lbTND2.TabIndex = 0;
            this.lbTND2.Text = "Phạm Bá Đức";
            this.lbTND2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbTND
            // 
            this.lbTND.BackColor = System.Drawing.SystemColors.Control;
            this.lbTND.Location = new System.Drawing.Point(6, 17);
            this.lbTND.Name = "lbTND";
            this.lbTND.Size = new System.Drawing.Size(86, 17);
            this.lbTND.TabIndex = 0;
            this.lbTND.Text = "Tên người dùng:";
            this.lbTND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btDangXuat
            // 
            this.btDangXuat.Location = new System.Drawing.Point(588, 7);
            this.btDangXuat.Name = "btDangXuat";
            this.btDangXuat.Size = new System.Drawing.Size(92, 47);
            this.btDangXuat.TabIndex = 0;
            this.btDangXuat.Text = "Đăng xuất";
            this.btDangXuat.UseVisualStyleBackColor = true;
            this.btDangXuat.Click += new System.EventHandler(this.btDangXuat_Click);
            // 
            // panelQLDSV
            // 
            this.panelQLDSV.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panelQLDSV.Controls.Add(this.panelContentQLDSV);
            this.panelQLDSV.Controls.Add(this.msQT);
            this.panelQLDSV.Location = new System.Drawing.Point(12, 60);
            this.panelQLDSV.Name = "panelQLDSV";
            this.panelQLDSV.Size = new System.Drawing.Size(673, 459);
            this.panelQLDSV.TabIndex = 0;
            // 
            // panelContentQLDSV
            // 
            this.panelContentQLDSV.BackColor = System.Drawing.SystemColors.Control;
            this.panelContentQLDSV.Location = new System.Drawing.Point(5, 31);
            this.panelContentQLDSV.Name = "panelContentQLDSV";
            this.panelContentQLDSV.Size = new System.Drawing.Size(662, 419);
            this.panelContentQLDSV.TabIndex = 1;
            // 
            // msQT
            // 
            this.msQT.BackColor = System.Drawing.SystemColors.Control;
            this.msQT.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.msQT.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.msiSV,
            this.msiGV,
            this.msiLHP,
            this.msiLTC,
            this.msiMH,
            this.msiD,
            this.msiTK});
            this.msQT.Location = new System.Drawing.Point(0, 0);
            this.msQT.Name = "msQT";
            this.msQT.Padding = new System.Windows.Forms.Padding(0);
            this.msQT.Size = new System.Drawing.Size(673, 24);
            this.msQT.TabIndex = 0;
            this.msQT.Text = "Quản trị";
            // 
            // msiSV
            // 
            this.msiSV.BackColor = System.Drawing.Color.White;
            this.msiSV.Margin = new System.Windows.Forms.Padding(2);
            this.msiSV.Name = "msiSV";
            this.msiSV.Size = new System.Drawing.Size(67, 20);
            this.msiSV.Text = "Sinh viên";
            this.msiSV.Click += new System.EventHandler(this.msiSV_Click);
            // 
            // msiGV
            // 
            this.msiGV.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.msiGV.Margin = new System.Windows.Forms.Padding(2);
            this.msiGV.Name = "msiGV";
            this.msiGV.Size = new System.Drawing.Size(75, 20);
            this.msiGV.Text = "Giảng viên";
            // 
            // msiLHP
            // 
            this.msiLHP.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.msiLHP.Margin = new System.Windows.Forms.Padding(2);
            this.msiLHP.Name = "msiLHP";
            this.msiLHP.Size = new System.Drawing.Size(92, 20);
            this.msiLHP.Text = "Lớp học phần";
            // 
            // msiLTC
            // 
            this.msiLTC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.msiLTC.Margin = new System.Windows.Forms.Padding(2);
            this.msiLTC.Name = "msiLTC";
            this.msiLTC.Size = new System.Drawing.Size(102, 20);
            this.msiLTC.Text = "Lớp hành chính";
            // 
            // msiMH
            // 
            this.msiMH.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.msiMH.Margin = new System.Windows.Forms.Padding(2);
            this.msiMH.Name = "msiMH";
            this.msiMH.Size = new System.Drawing.Size(67, 20);
            this.msiMH.Text = "Môn học";
            // 
            // msiD
            // 
            this.msiD.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.msiD.Margin = new System.Windows.Forms.Padding(2);
            this.msiD.Name = "msiD";
            this.msiD.Size = new System.Drawing.Size(47, 20);
            this.msiD.Text = "Điểm";
            // 
            // msiTK
            // 
            this.msiTK.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.msiTK.Margin = new System.Windows.Forms.Padding(2);
            this.msiTK.Name = "msiTK";
            this.msiTK.Size = new System.Drawing.Size(69, 20);
            this.msiTK.Text = "Tài khoản";
            this.msiTK.Click += new System.EventHandler(this.msiTK_Click);
            // 
            // FrmQLDSV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 522);
            this.Controls.Add(this.panelQLDSV);
            this.Controls.Add(this.btDangXuat);
            this.Controls.Add(this.panel3);
            this.MainMenuStrip = this.msQT;
            this.Name = "FrmQLDSV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý điểm sinh viên";
            this.panel3.ResumeLayout(false);
            this.panelQLDSV.ResumeLayout(false);
            this.panelQLDSV.PerformLayout();
            this.msQT.ResumeLayout(false);
            this.msQT.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Panel panel3;
        private Button btDangXuat;
        private Label lbTND2;
        private Label lbTND;
        private Panel panelQLDSV;
        private MenuStrip msQT;
        private ToolStripMenuItem msiSV;
        private ToolStripMenuItem msiGV;
        private ToolStripMenuItem msiLHP;
        private ToolStripMenuItem msiLTC;
        private ToolStripMenuItem msiMH;
        private ToolStripMenuItem msiD;
        private ToolStripMenuItem msiTK;
        private Panel panelContentQLDSV;
    }
}