﻿using QLDSV2.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLDSV2
{
    public partial class FrmSinhVien : Form
    {
        BLLSinhVien bLLSinhVien;
        BLLKhoa bLLKhoa;

        bool isAddingSV;
        public FrmSinhVien()
        {
            InitializeComponent();

            bLLSinhVien = new BLLSinhVien();
            bLLKhoa = new BLLKhoa();
            isAddingSV = false;

            LoadDataSinhVien();
            LoadComboBoxData();
            LoadButton();
            SetEnableTextBoxThongTin(false);
        }

        private void LoadDataSinhVien()
        {
            //Đổ dữ liệu vào trong data grid view dựa vào tên sin viên, mã lớp, mã khoa từ group box tìm kiếm

            var tenSinhVien = tbTKT.Text;
            var maLopSinhVien = tbTKL.Text;
            string maKhoa = "";
            if(cbbK.SelectedValue != null) maKhoa = cbbK.SelectedValue.ToString();
            
            dvgSV.DataSource = bLLSinhVien.GetAllSinhVien(tenSinhVien, maLopSinhVien, maKhoa);
            dvgSV.ReadOnly = true;
        }

        private void LoadComboBoxData()
        {
            //cbbK
            cbbK.DataSource = bLLKhoa.GetAllKhoa();
            cbbK.DisplayMember = "TenKhoa";
            cbbK.ValueMember = "MaKhoa";
            cbbK.SelectedIndex = -1;

            //cbbGT
            cbbGT.DataSource = new List<KeyValuePair<int, string>>()
            {
                new KeyValuePair<int, string>(0, "Nam"),
                new KeyValuePair<int, string>(1, "Nữ"),
            };
            cbbGT.DisplayMember = "Value";
            cbbGT.ValueMember = "Key";
            cbbGT.SelectedIndex = -1;
        }

        private void LoadButton()
        {
            SetEnabledParentButton(true);
            SetEnabledChildrenButton(false);
        }

        private void SetEnabledParentButton(bool _enable)
        {
            btT.Enabled = _enable;
            btS.Enabled = _enable;
            btX.Enabled = _enable;
        }

        private void SetEnabledChildrenButton(bool _enable)
        {
            btPH.Enabled = _enable;
            btG.Enabled = _enable;
            btH.Enabled = _enable;
        }

        private void SetEnableTextBoxThongTin(bool _enable)
        {
            tbM.Enabled = _enable;
            tbT.Enabled = _enable;
            tbNS.Enabled = _enable;
            cbbGT.Enabled = _enable;
            tbDC.Enabled = _enable;
            tbSDT.Enabled = _enable;
            tbEmail.Enabled = _enable;
            tbLHC.Enabled = _enable;
        }

        private void SetDefaultValueTKGroupBox()
        {
            //reset giá trị các ô tìm kiếm
            tbTKT.Text = "";
            tbTKL.Text = "";
            cbbK.SelectedIndex = -1;
        }

        private void SetDefaultValueTTGroupBox()
        {
            //reset giá trị các ô thông tin
            tbM.Text = "";
            tbT.Text = "";
            tbNS.Text = "";
            cbbGT.SelectedIndex = -1;
            tbDC.Text = "";
            tbSDT.Text = "";
            tbEmail.Text = "";
            tbLHC.Text = "";
        }

        private void SetValueTTGroupBoxFromDVG()
        {
            if (dvgSV.CurrentRow == null) return;
            tbM.Text = dvgSV.CurrentRow.Cells[0].Value.ToString();
            tbT.Text = dvgSV.CurrentRow.Cells[1].Value.ToString();
            tbNS.Text = ((DateTime)dvgSV.CurrentRow.Cells[2].Value).ToString("dd/MM/yyyy");
            cbbGT.SelectedValue = dvgSV.CurrentRow.Cells[3].Value;
            tbDC.Text = dvgSV.CurrentRow.Cells[4].Value.ToString();
            tbSDT.Text = dvgSV.CurrentRow.Cells[5].Value.ToString();
            tbEmail.Text = dvgSV.CurrentRow.Cells[6].Value.ToString();
            tbLHC.Text = dvgSV.CurrentRow.Cells[7].Value.ToString();
        }

        private void btTK_Click(object sender, EventArgs e)
        {
            LoadDataSinhVien();
        }

        private void btTKAll_Click(object sender, EventArgs e)
        {
           SetDefaultValueTKGroupBox();
           LoadDataSinhVien();
        }

        private void dvgSV_SelectionChanged(object sender, EventArgs e)
        {
            SetValueTTGroupBoxFromDVG();
        }

        private void btT_Click(object sender, EventArgs e)
        {
            isAddingSV = true;
            gbTKSV.Enabled = false;
            panel1.Enabled = false;
            SetEnabledParentButton(false);
            SetEnabledChildrenButton(true);
            SetEnableTextBoxThongTin(true);
            SetDefaultValueTTGroupBox();
        }

        private void btS_Click(object sender, EventArgs e)
        {
            gbTKSV.Enabled = false;
            panel1.Enabled = false;
            SetEnabledParentButton(false);
            SetEnabledChildrenButton(true);
            SetEnableTextBoxThongTin(true);
            tbM.Enabled = false;
        }

        private void btPH_Click(object sender, EventArgs e)
        {
            if (isAddingSV)
            {
                SetDefaultValueTTGroupBox();
                return;
            }
            SetValueTTGroupBoxFromDVG();
        }

        private void btH_Click(object sender, EventArgs e)
        {
            SetValueTTGroupBoxFromDVG();

            if(isAddingSV) isAddingSV = false;
            gbTKSV.Enabled = true;
            panel1.Enabled = true;
            SetEnabledParentButton(true);
            SetEnabledChildrenButton(false);
            SetEnableTextBoxThongTin(false);
        }

        private void btG_Click(object sender, EventArgs e)
        {
            if (isAddingSV)
            {
                if(bLLSinhVien.ThemSinhVien(tbM.Text, tbT.Text, tbNS.Text, (int)cbbGT.SelectedValue, tbDC.Text, tbSDT.Text, tbEmail.Text, tbLHC.Text))
                {
                    MessageBox.Show("Thêm sinh viên thành công", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    isAddingSV = false;
                    gbTKSV.Enabled = true;
                    panel1.Enabled = true;
                    SetEnabledParentButton(true);
                    SetEnabledChildrenButton(false);
                    SetEnableTextBoxThongTin(false);
                    SetDefaultValueTKGroupBox();
                    LoadDataSinhVien();
                }
            }
            else
            {
                if(bLLSinhVien.SuaNhanVien(tbM.Text, tbT.Text, tbNS.Text, (int)cbbGT.SelectedValue, tbDC.Text, tbSDT.Text, tbEmail.Text, tbLHC.Text))
                {
                    MessageBox.Show("Sửa thông tin sinh viên thành công", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    gbTKSV.Enabled = true;
                    panel1.Enabled = true;
                    SetEnabledParentButton(true);
                    SetEnabledChildrenButton(false);
                    SetEnableTextBoxThongTin(false);
                    SetDefaultValueTKGroupBox();
                    LoadDataSinhVien();
                }
            }
        }

        private void btX_Click(object sender, EventArgs e)
        {
            // Hiển thị MessageBox xác nhận
            DialogResult result = MessageBox.Show("Bạn thực sự muốn xóa sinh viên?",  "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Kiểm tra kết quả người dùng chọn
            if (result == DialogResult.Yes) // Nếu người dùng nhấn Yes
            {
                if (bLLSinhVien.XoaSinhVien(tbM.Text.Trim()))
                {
                    MessageBox.Show("Xóa sinh viên thành công", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    SetDefaultValueTKGroupBox();
                    LoadDataSinhVien();
                }
            }
        }
    }
}
