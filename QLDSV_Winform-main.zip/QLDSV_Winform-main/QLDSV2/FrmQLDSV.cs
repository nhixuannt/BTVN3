﻿using QLDSV2.BLL;
using QLDSV2.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLDSV2
{
    public partial class FrmQLDSV : Form
    {
        private object nguoiDung;

        #region Load Form Quản lý điểm sinh viên

        public FrmQLDSV(object _nguoiDung)
        {
            InitializeComponent();

            LoadFrmQLDSV(_nguoiDung);
        }

        private void btDangXuat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadFrmQLDSV(object _nguoiDung)
        {
            InitializeStripItems(_nguoiDung);

            nguoiDung = _nguoiDung;
        }

        private void InitializeStripItems(object _nguoiDung)
        {

            List<ToolStripMenuItem> msiToRemove = new List<ToolStripMenuItem>();

            if (_nguoiDung is GiangVien)
            {
                msiToRemove.AddRange(new[] { msiTK, msiSV, msiGV, msiLTC, msiLHP, msiMH });
                lbTND2.Text = ((GiangVien)_nguoiDung).tenGiangVien;
            }
            else if (_nguoiDung is NhanVienAdmin)
            {
                msiToRemove.AddRange(new[] { msiD, msiSV, msiGV, msiLTC, msiLHP, msiMH });
                lbTND2.Text = ((NhanVienAdmin)_nguoiDung).tenNhanVienAdmin;
            }
            else
            {
                msiToRemove.AddRange(new[] { msiD, msiTK });
                lbTND2.Text = ((NhanVienQuanTri)_nguoiDung).tenNhanVienQuanTri;
            }

            foreach (var menuStripItem in msiToRemove)
            {
                if (msQT.Items.Contains(menuStripItem))
                {
                    msQT.Items.Remove(menuStripItem);
                }
            }
        }

        #endregion


        private void LoadChildForm(Form f)
        {
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;

            f.TopLevel = false;
            f.TopMost = true;

            panelContentQLDSV.Controls.Clear();
            panelContentQLDSV.Controls.Add(f);

            f.Show();
        }

        private void msiSV_Click(object sender, EventArgs e)
        {
            var frmSinhVien = new FrmSinhVien();
            LoadChildForm(frmSinhVien);
        }

        private void msiTK_Click(object sender, EventArgs e)
        {
            var frmTaiKhoan = new FrmTaiKhoan();
            LoadChildForm(frmTaiKhoan);
        }
    }
}
