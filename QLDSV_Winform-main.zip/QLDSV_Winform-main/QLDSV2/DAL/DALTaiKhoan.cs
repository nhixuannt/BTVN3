﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLDSV2.DAL
{
    internal class DALTaiKhoan
    {
        QLDSVEntities db = new QLDSVEntities();

        public GiangVien ValidateTaiKhoanGiangVien(string tenDangNhap, string matKhau)
        {
            var x = from _taiKhoan in db.TaiKhoanGiangVien
                    join _giangVien in db.GiangVien on _taiKhoan.maGiangVien equals _giangVien.maGiangVien
                    where _taiKhoan.tenDangNhap.Equals(tenDangNhap) && _taiKhoan.matKhau.Equals(matKhau)
                    select _giangVien;

            var result = x.SingleOrDefault();
            return result;
        }

        public NhanVienAdmin ValidateTaiKhoanAdmin(string tenDangNhap, string matKhau)
        {
            var x = from _taiKhoan in db.TaiKhoanAdmin
                    join _nhanVienAdmin in db.NhanVienAdmin on _taiKhoan.maNhanVienAdmin equals _nhanVienAdmin.maNhanVienAdmin
                    where _taiKhoan.tenDangNhap.Equals(tenDangNhap) && _taiKhoan.matKhau.Equals(matKhau)
                    select _nhanVienAdmin;

            var result = x.SingleOrDefault();
            return result;
        }

        public NhanVienQuanTri ValidateTaiKhoanNhanVienQuanTri(string tenDangNhap, string matKhau)
        {
            var x = from _taiKhoan in db.TaiKhoanNhanVienQuanTri
                    join _nhanVienQuanTri in db.NhanVienQuanTri on _taiKhoan.maNhanVienQuanTri equals _nhanVienQuanTri.maNhanVienQuanTri
                    where _taiKhoan.tenDangNhap.Equals(tenDangNhap) && _taiKhoan.matKhau.Equals(matKhau)
                    select _nhanVienQuanTri;

            var result = x.SingleOrDefault();
            return result;
        }
    }
}
