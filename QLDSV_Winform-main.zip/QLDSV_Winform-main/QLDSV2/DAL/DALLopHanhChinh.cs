﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLDSV2.DAL
{
    internal class DALLopHanhChinh
    {
        QLDSVEntities db = new QLDSVEntities();
        public bool CheckMaLopHanhChinhTonTai(string _maLopHanhChinh)
        {
            return db.LopHanhChinh.Any(x => x.maLopHanhchinh.Equals(_maLopHanhChinh));
        }
    }
}
