﻿using QLDSV2.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLDSV2.DAL
{
    internal class DALKhoa
    {
        QLDSVEntities db = new QLDSVEntities();

        public List<DTOKhoa> GetAllKhoa()
        {
            var khoas = from khoa in db.Khoa
                        select new DTOKhoa
                        {
                            MaKhoa = khoa.maKhoa,
                            TenKhoa = khoa.tenKhoa,
                            NamThanhLap = khoa.namThanhLap,
                            SoDienThoai = khoa.soDienThoai,
                        };

            return khoas.ToList();
        }
    }
}
