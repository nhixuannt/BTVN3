﻿using QLDSV2.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace QLDSV2.DAL
{
    internal class DALSinhVien
    {
        QLDSVEntities db = new QLDSVEntities();

        public List<DTOSinhVien> GetAllSinhVien(string _tenSinhVien, string _maLop, string _maKhoa)
        {
            if (_tenSinhVien == null) _tenSinhVien = "";
            if (_maLop == null) _maLop = "";
            if (_maKhoa == null) _maKhoa = "";

            var sinhViens = from sinhVien in db.SinhVien
                            join lopHanhChinh in db.LopHanhChinh on sinhVien.maLopHanhChinh equals lopHanhChinh.maLopHanhchinh
                            where sinhVien.tenSinhVien.Contains(_tenSinhVien)
                            && sinhVien.maLopHanhChinh.Contains(_maLop)
                            && lopHanhChinh.maKhoa.Contains(_maKhoa)
                            select new DTOSinhVien
                            {
                                MaSinhVien = sinhVien.maSinhVien,
                                TenSinhVien = sinhVien.tenSinhVien,
                                NgaySinh = sinhVien.ngaySinh,
                                GioiTinh = sinhVien.gioiTinh,
                                DiaChi = sinhVien.diaChi,
                                SoDienThoai = sinhVien.soDienThoai,
                                Email = sinhVien.email,
                                MaLopHanhChinh = sinhVien.maLopHanhChinh,
                            };
            return sinhViens.ToList();
        }

        public bool ThemSinhVien(DTOSinhVien newSinhVien)
        {
            SinhVien sinhVien = new SinhVien()
            {
                maSinhVien = newSinhVien.MaSinhVien,
                tenSinhVien = newSinhVien.TenSinhVien,
                ngaySinh = newSinhVien.NgaySinh,
                gioiTinh = newSinhVien.GioiTinh,
                diaChi = newSinhVien.DiaChi,
                soDienThoai = newSinhVien.SoDienThoai,
                email = newSinhVien.Email,
                maLopHanhChinh = newSinhVien.MaLopHanhChinh
            };

            try
            {
                db.SinhVien.Add(sinhVien);
                db.SaveChanges();
                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Thêm sinh viên thất bại với lỗi: " + ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool XoaSinhVien(string _maSV)
        {
            var sinhVien = db.SinhVien.FirstOrDefault(x => x.maSinhVien == _maSV);
            try
            {
                db.SinhVien.Remove(sinhVien);
                db.SaveChanges();
                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Xóa sinh viên thất bại với lỗi: " + ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool SuaSinhVien(DTOSinhVien newSinhVien)
        {
            var sinhVien = db.SinhVien.FirstOrDefault(x => x.maSinhVien == newSinhVien.MaSinhVien);

            sinhVien.tenSinhVien = newSinhVien.TenSinhVien;
            sinhVien.ngaySinh = newSinhVien.NgaySinh;
            sinhVien.gioiTinh = newSinhVien.GioiTinh;
            sinhVien.diaChi = newSinhVien.DiaChi;
            sinhVien.soDienThoai = newSinhVien.SoDienThoai;
            sinhVien.email = newSinhVien.Email;
            sinhVien.maLopHanhChinh = newSinhVien.MaLopHanhChinh;

            try
            {
                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sửa sinh viên thất bại với lỗi: " + ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool CheckMaSVTonTai(string _maSV)
        {
            return db.SinhVien.Any(x => x.maSinhVien.Equals(_maSV));
        }

        public bool CheckEmailSVTonTai(string _emailSV)
        {
            return db.SinhVien.Any(x => x.email.Equals(_emailSV));
        }
    }
}
