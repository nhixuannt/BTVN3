﻿namespace QLDSV2
{
    partial class FrmTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tcQTTK = new System.Windows.Forms.TabControl();
            this.tpTKGV = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dgvTKGV = new System.Windows.Forms.DataGridView();
            this.gbTTTKGV = new System.Windows.Forms.GroupBox();
            this.btDLMKTKGV = new System.Windows.Forms.Button();
            this.btSTKGV = new System.Windows.Forms.Button();
            this.btTTKGV = new System.Windows.Forms.Button();
            this.btXTKGV = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lbTHTTKGV = new System.Windows.Forms.Label();
            this.btLMTKGV = new System.Windows.Forms.Button();
            this.tbTTKGV = new System.Windows.Forms.TextBox();
            this.lbTTKGV = new System.Windows.Forms.Label();
            this.gbTKTKGV = new System.Windows.Forms.GroupBox();
            this.btTKTKGVAll = new System.Windows.Forms.Button();
            this.btTKTKGV = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbTKTKGV = new System.Windows.Forms.Label();
            this.tpTKNVQT = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dgvTKQT = new System.Windows.Forms.DataGridView();
            this.gbTTTKQT = new System.Windows.Forms.GroupBox();
            this.btDLMKTKQT = new System.Windows.Forms.Button();
            this.btSTKQT = new System.Windows.Forms.Button();
            this.btTTKQT = new System.Windows.Forms.Button();
            this.btXTKQT = new System.Windows.Forms.Button();
            this.tbTHTTKQT = new System.Windows.Forms.TextBox();
            this.lbTHTTKQT = new System.Windows.Forms.Label();
            this.btLMTKQT = new System.Windows.Forms.Button();
            this.tbTTKQT = new System.Windows.Forms.TextBox();
            this.lbTTKQT = new System.Windows.Forms.Label();
            this.gbTKTKQT = new System.Windows.Forms.GroupBox();
            this.btTKTKQTAll = new System.Windows.Forms.Button();
            this.btTKTKQT = new System.Windows.Forms.Button();
            this.tbTKTKQT = new System.Windows.Forms.TextBox();
            this.lbTKTKQT = new System.Windows.Forms.Label();
            this.tpTKAD = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.dvgTKAD = new System.Windows.Forms.DataGridView();
            this.gbTTTKAD = new System.Windows.Forms.GroupBox();
            this.btDLMKTKAD = new System.Windows.Forms.Button();
            this.btSTKAD = new System.Windows.Forms.Button();
            this.btTTKAD = new System.Windows.Forms.Button();
            this.btXTKAD = new System.Windows.Forms.Button();
            this.tbTHTTKAD = new System.Windows.Forms.TextBox();
            this.lbTHTTKAD = new System.Windows.Forms.Label();
            this.btLMTKAD = new System.Windows.Forms.Button();
            this.tbTTKAD = new System.Windows.Forms.TextBox();
            this.lbTTKAD = new System.Windows.Forms.Label();
            this.gbTKTKAD = new System.Windows.Forms.GroupBox();
            this.btTKTKADAll = new System.Windows.Forms.Button();
            this.btTKTKAD = new System.Windows.Forms.Button();
            this.tbTKTKAD = new System.Windows.Forms.TextBox();
            this.lbTKTKAD = new System.Windows.Forms.Label();
            this.tcQTTK.SuspendLayout();
            this.tpTKGV.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKGV)).BeginInit();
            this.gbTTTKGV.SuspendLayout();
            this.gbTKTKGV.SuspendLayout();
            this.tpTKNVQT.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKQT)).BeginInit();
            this.gbTTTKQT.SuspendLayout();
            this.gbTKTKQT.SuspendLayout();
            this.tpTKAD.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgTKAD)).BeginInit();
            this.gbTTTKAD.SuspendLayout();
            this.gbTKTKAD.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcQTTK
            // 
            this.tcQTTK.Controls.Add(this.tpTKGV);
            this.tcQTTK.Controls.Add(this.tpTKNVQT);
            this.tcQTTK.Controls.Add(this.tpTKAD);
            this.tcQTTK.Location = new System.Drawing.Point(3, 7);
            this.tcQTTK.Name = "tcQTTK";
            this.tcQTTK.SelectedIndex = 0;
            this.tcQTTK.Size = new System.Drawing.Size(653, 415);
            this.tcQTTK.TabIndex = 1;
            // 
            // tpTKGV
            // 
            this.tpTKGV.Controls.Add(this.panel8);
            this.tpTKGV.Controls.Add(this.gbTTTKGV);
            this.tpTKGV.Controls.Add(this.gbTKTKGV);
            this.tpTKGV.Location = new System.Drawing.Point(4, 22);
            this.tpTKGV.Name = "tpTKGV";
            this.tpTKGV.Padding = new System.Windows.Forms.Padding(3);
            this.tpTKGV.Size = new System.Drawing.Size(645, 389);
            this.tpTKGV.TabIndex = 0;
            this.tpTKGV.Text = "Tài khoản giảng viên";
            this.tpTKGV.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dgvTKGV);
            this.panel8.Location = new System.Drawing.Point(5, 212);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(629, 168);
            this.panel8.TabIndex = 2;
            // 
            // dgvTKGV
            // 
            this.dgvTKGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTKGV.Location = new System.Drawing.Point(3, 3);
            this.dgvTKGV.Name = "dgvTKGV";
            this.dgvTKGV.Size = new System.Drawing.Size(623, 161);
            this.dgvTKGV.TabIndex = 0;
            // 
            // gbTTTKGV
            // 
            this.gbTTTKGV.Controls.Add(this.btDLMKTKGV);
            this.gbTTTKGV.Controls.Add(this.btSTKGV);
            this.gbTTTKGV.Controls.Add(this.btTTKGV);
            this.gbTTTKGV.Controls.Add(this.btXTKGV);
            this.gbTTTKGV.Controls.Add(this.textBox3);
            this.gbTTTKGV.Controls.Add(this.lbTHTTKGV);
            this.gbTTTKGV.Controls.Add(this.btLMTKGV);
            this.gbTTTKGV.Controls.Add(this.tbTTKGV);
            this.gbTTTKGV.Controls.Add(this.lbTTKGV);
            this.gbTTTKGV.Location = new System.Drawing.Point(5, 85);
            this.gbTTTKGV.Name = "gbTTTKGV";
            this.gbTTTKGV.Size = new System.Drawing.Size(629, 120);
            this.gbTTTKGV.TabIndex = 1;
            this.gbTTTKGV.TabStop = false;
            this.gbTTTKGV.Text = "Thông tin chi tiết";
            // 
            // btDLMKTKGV
            // 
            this.btDLMKTKGV.Location = new System.Drawing.Point(456, 82);
            this.btDLMKTKGV.Name = "btDLMKTKGV";
            this.btDLMKTKGV.Size = new System.Drawing.Size(112, 27);
            this.btDLMKTKGV.TabIndex = 10;
            this.btDLMKTKGV.Text = "Đặt lại mật khẩu";
            this.btDLMKTKGV.UseVisualStyleBackColor = true;
            // 
            // btSTKGV
            // 
            this.btSTKGV.Location = new System.Drawing.Point(258, 82);
            this.btSTKGV.Name = "btSTKGV";
            this.btSTKGV.Size = new System.Drawing.Size(121, 27);
            this.btSTKGV.TabIndex = 8;
            this.btSTKGV.Text = "Sửa";
            this.btSTKGV.UseVisualStyleBackColor = true;
            // 
            // btTTKGV
            // 
            this.btTTKGV.Location = new System.Drawing.Point(154, 53);
            this.btTTKGV.Name = "btTTKGV";
            this.btTTKGV.Size = new System.Drawing.Size(121, 27);
            this.btTTKGV.TabIndex = 7;
            this.btTTKGV.Text = "Thêm";
            this.btTTKGV.UseVisualStyleBackColor = true;
            // 
            // btXTKGV
            // 
            this.btXTKGV.Location = new System.Drawing.Point(356, 53);
            this.btXTKGV.Name = "btXTKGV";
            this.btXTKGV.Size = new System.Drawing.Size(121, 27);
            this.btXTKGV.TabIndex = 9;
            this.btXTKGV.Text = "Xóa";
            this.btXTKGV.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(371, 27);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(147, 20);
            this.textBox3.TabIndex = 5;
            // 
            // lbTHTTKGV
            // 
            this.lbTHTTKGV.Location = new System.Drawing.Point(287, 26);
            this.lbTHTTKGV.Name = "lbTHTTKGV";
            this.lbTHTTKGV.Size = new System.Drawing.Size(92, 20);
            this.lbTHTTKGV.TabIndex = 0;
            this.lbTHTTKGV.Text = "Tên hiển thị:";
            this.lbTHTTKGV.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btLMTKGV
            // 
            this.btLMTKGV.Location = new System.Drawing.Point(60, 82);
            this.btLMTKGV.Name = "btLMTKGV";
            this.btLMTKGV.Size = new System.Drawing.Size(121, 27);
            this.btLMTKGV.TabIndex = 6;
            this.btLMTKGV.Text = "Làm mới";
            this.btLMTKGV.UseVisualStyleBackColor = true;
            // 
            // tbTTKGV
            // 
            this.tbTTKGV.Location = new System.Drawing.Point(99, 27);
            this.tbTTKGV.Name = "tbTTKGV";
            this.tbTTKGV.Size = new System.Drawing.Size(147, 20);
            this.tbTTKGV.TabIndex = 4;
            // 
            // lbTTKGV
            // 
            this.lbTTKGV.Location = new System.Drawing.Point(16, 26);
            this.lbTTKGV.Name = "lbTTKGV";
            this.lbTTKGV.Size = new System.Drawing.Size(103, 20);
            this.lbTTKGV.TabIndex = 0;
            this.lbTTKGV.Text = "Tên tài khoản:";
            this.lbTTKGV.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gbTKTKGV
            // 
            this.gbTKTKGV.Controls.Add(this.btTKTKGVAll);
            this.gbTKTKGV.Controls.Add(this.btTKTKGV);
            this.gbTKTKGV.Controls.Add(this.textBox1);
            this.gbTKTKGV.Controls.Add(this.lbTKTKGV);
            this.gbTKTKGV.Location = new System.Drawing.Point(5, 5);
            this.gbTKTKGV.Name = "gbTKTKGV";
            this.gbTKTKGV.Size = new System.Drawing.Size(629, 75);
            this.gbTKTKGV.TabIndex = 0;
            this.gbTKTKGV.TabStop = false;
            this.gbTKTKGV.Text = "Tìm kiếm tài khoản giảng viên";
            // 
            // btTKTKGVAll
            // 
            this.btTKTKGVAll.Location = new System.Drawing.Point(534, 32);
            this.btTKTKGVAll.Name = "btTKTKGVAll";
            this.btTKTKGVAll.Size = new System.Drawing.Size(80, 20);
            this.btTKTKGVAll.TabIndex = 3;
            this.btTKTKGVAll.Text = "Tất cả";
            this.btTKTKGVAll.UseVisualStyleBackColor = true;
            // 
            // btTKTKGV
            // 
            this.btTKTKGV.Location = new System.Drawing.Point(415, 31);
            this.btTKTKGV.Name = "btTKTKGV";
            this.btTKTKGV.Size = new System.Drawing.Size(80, 20);
            this.btTKTKGV.TabIndex = 2;
            this.btTKTKGV.Text = "Tìm kiếm";
            this.btTKTKGV.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(120, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(259, 20);
            this.textBox1.TabIndex = 1;
            // 
            // lbTKTKGV
            // 
            this.lbTKTKGV.Location = new System.Drawing.Point(15, 31);
            this.lbTKTKGV.Name = "lbTKTKGV";
            this.lbTKTKGV.Size = new System.Drawing.Size(99, 20);
            this.lbTKTKGV.TabIndex = 0;
            this.lbTKTKGV.Text = "Tên người dùng:";
            this.lbTKTKGV.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tpTKNVQT
            // 
            this.tpTKNVQT.Controls.Add(this.panel9);
            this.tpTKNVQT.Controls.Add(this.gbTTTKQT);
            this.tpTKNVQT.Controls.Add(this.gbTKTKQT);
            this.tpTKNVQT.Location = new System.Drawing.Point(4, 22);
            this.tpTKNVQT.Name = "tpTKNVQT";
            this.tpTKNVQT.Padding = new System.Windows.Forms.Padding(3);
            this.tpTKNVQT.Size = new System.Drawing.Size(645, 389);
            this.tpTKNVQT.TabIndex = 1;
            this.tpTKNVQT.Text = "Tài khoản quản trị";
            this.tpTKNVQT.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.dgvTKQT);
            this.panel9.Location = new System.Drawing.Point(5, 211);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(629, 168);
            this.panel9.TabIndex = 3;
            // 
            // dgvTKQT
            // 
            this.dgvTKQT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTKQT.Location = new System.Drawing.Point(3, 3);
            this.dgvTKQT.Name = "dgvTKQT";
            this.dgvTKQT.Size = new System.Drawing.Size(623, 162);
            this.dgvTKQT.TabIndex = 0;
            // 
            // gbTTTKQT
            // 
            this.gbTTTKQT.Controls.Add(this.btDLMKTKQT);
            this.gbTTTKQT.Controls.Add(this.btSTKQT);
            this.gbTTTKQT.Controls.Add(this.btTTKQT);
            this.gbTTTKQT.Controls.Add(this.btXTKQT);
            this.gbTTTKQT.Controls.Add(this.tbTHTTKQT);
            this.gbTTTKQT.Controls.Add(this.lbTHTTKQT);
            this.gbTTTKQT.Controls.Add(this.btLMTKQT);
            this.gbTTTKQT.Controls.Add(this.tbTTKQT);
            this.gbTTTKQT.Controls.Add(this.lbTTKQT);
            this.gbTTTKQT.Location = new System.Drawing.Point(5, 85);
            this.gbTTTKQT.Name = "gbTTTKQT";
            this.gbTTTKQT.Size = new System.Drawing.Size(633, 120);
            this.gbTTTKQT.TabIndex = 0;
            this.gbTTTKQT.TabStop = false;
            this.gbTTTKQT.Text = "Thông tin chi tiết";
            // 
            // btDLMKTKQT
            // 
            this.btDLMKTKQT.Location = new System.Drawing.Point(436, 86);
            this.btDLMKTKQT.Name = "btDLMKTKQT";
            this.btDLMKTKQT.Size = new System.Drawing.Size(112, 27);
            this.btDLMKTKQT.TabIndex = 10;
            this.btDLMKTKQT.Text = "Đặt lại mật khẩu";
            this.btDLMKTKQT.UseVisualStyleBackColor = true;
            // 
            // btSTKQT
            // 
            this.btSTKQT.Location = new System.Drawing.Point(253, 86);
            this.btSTKQT.Name = "btSTKQT";
            this.btSTKQT.Size = new System.Drawing.Size(121, 27);
            this.btSTKQT.TabIndex = 8;
            this.btSTKQT.Text = "Sửa";
            this.btSTKQT.UseVisualStyleBackColor = true;
            // 
            // btTTKQT
            // 
            this.btTTKQT.Location = new System.Drawing.Point(159, 56);
            this.btTTKQT.Name = "btTTKQT";
            this.btTTKQT.Size = new System.Drawing.Size(121, 27);
            this.btTTKQT.TabIndex = 7;
            this.btTTKQT.Text = "Thêm";
            this.btTTKQT.UseVisualStyleBackColor = true;
            // 
            // btXTKQT
            // 
            this.btXTKQT.Location = new System.Drawing.Point(350, 56);
            this.btXTKQT.Name = "btXTKQT";
            this.btXTKQT.Size = new System.Drawing.Size(121, 27);
            this.btXTKQT.TabIndex = 9;
            this.btXTKQT.Text = "Xóa";
            this.btXTKQT.UseVisualStyleBackColor = true;
            // 
            // tbTHTTKQT
            // 
            this.tbTHTTKQT.Location = new System.Drawing.Point(366, 30);
            this.tbTHTTKQT.Name = "tbTHTTKQT";
            this.tbTHTTKQT.Size = new System.Drawing.Size(147, 20);
            this.tbTHTTKQT.TabIndex = 5;
            // 
            // lbTHTTKQT
            // 
            this.lbTHTTKQT.Location = new System.Drawing.Point(282, 29);
            this.lbTHTTKQT.Name = "lbTHTTKQT";
            this.lbTHTTKQT.Size = new System.Drawing.Size(92, 20);
            this.lbTHTTKQT.TabIndex = 0;
            this.lbTHTTKQT.Text = "Tên hiển thị:";
            this.lbTHTTKQT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btLMTKQT
            // 
            this.btLMTKQT.Location = new System.Drawing.Point(68, 86);
            this.btLMTKQT.Name = "btLMTKQT";
            this.btLMTKQT.Size = new System.Drawing.Size(121, 27);
            this.btLMTKQT.TabIndex = 6;
            this.btLMTKQT.Text = "Làm mới";
            this.btLMTKQT.UseVisualStyleBackColor = true;
            // 
            // tbTTKQT
            // 
            this.tbTTKQT.Location = new System.Drawing.Point(94, 30);
            this.tbTTKQT.Name = "tbTTKQT";
            this.tbTTKQT.Size = new System.Drawing.Size(147, 20);
            this.tbTTKQT.TabIndex = 4;
            // 
            // lbTTKQT
            // 
            this.lbTTKQT.Location = new System.Drawing.Point(11, 29);
            this.lbTTKQT.Name = "lbTTKQT";
            this.lbTTKQT.Size = new System.Drawing.Size(103, 20);
            this.lbTTKQT.TabIndex = 0;
            this.lbTTKQT.Text = "Tên tài khoản:";
            this.lbTTKQT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gbTKTKQT
            // 
            this.gbTKTKQT.Controls.Add(this.btTKTKQTAll);
            this.gbTKTKQT.Controls.Add(this.btTKTKQT);
            this.gbTKTKQT.Controls.Add(this.tbTKTKQT);
            this.gbTKTKQT.Controls.Add(this.lbTKTKQT);
            this.gbTKTKQT.Location = new System.Drawing.Point(5, 5);
            this.gbTKTKQT.Name = "gbTKTKQT";
            this.gbTKTKQT.Size = new System.Drawing.Size(634, 75);
            this.gbTKTKQT.TabIndex = 1;
            this.gbTKTKQT.TabStop = false;
            this.gbTKTKQT.Text = "Tìm kiếm tài khoản nhân viên quản trị";
            // 
            // btTKTKQTAll
            // 
            this.btTKTKQTAll.Location = new System.Drawing.Point(510, 32);
            this.btTKTKQTAll.Name = "btTKTKQTAll";
            this.btTKTKQTAll.Size = new System.Drawing.Size(80, 20);
            this.btTKTKQTAll.TabIndex = 3;
            this.btTKTKQTAll.Text = "Tất cả";
            this.btTKTKQTAll.UseVisualStyleBackColor = true;
            // 
            // btTKTKQT
            // 
            this.btTKTKQT.Location = new System.Drawing.Point(391, 32);
            this.btTKTKQT.Name = "btTKTKQT";
            this.btTKTKQT.Size = new System.Drawing.Size(80, 20);
            this.btTKTKQT.TabIndex = 2;
            this.btTKTKQT.Text = "Tìm kiếm";
            this.btTKTKQT.UseVisualStyleBackColor = true;
            // 
            // tbTKTKQT
            // 
            this.tbTKTKQT.Location = new System.Drawing.Point(120, 32);
            this.tbTKTKQT.Name = "tbTKTKQT";
            this.tbTKTKQT.Size = new System.Drawing.Size(203, 20);
            this.tbTKTKQT.TabIndex = 1;
            // 
            // lbTKTKQT
            // 
            this.lbTKTKQT.Location = new System.Drawing.Point(15, 31);
            this.lbTKTKQT.Name = "lbTKTKQT";
            this.lbTKTKQT.Size = new System.Drawing.Size(99, 20);
            this.lbTKTKQT.TabIndex = 0;
            this.lbTKTKQT.Text = "Tên người dùng:";
            this.lbTKTKQT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tpTKAD
            // 
            this.tpTKAD.Controls.Add(this.panel10);
            this.tpTKAD.Controls.Add(this.gbTTTKAD);
            this.tpTKAD.Controls.Add(this.gbTKTKAD);
            this.tpTKAD.Location = new System.Drawing.Point(4, 22);
            this.tpTKAD.Name = "tpTKAD";
            this.tpTKAD.Size = new System.Drawing.Size(645, 389);
            this.tpTKAD.TabIndex = 2;
            this.tpTKAD.Text = "Tài khoản admin";
            this.tpTKAD.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.dvgTKAD);
            this.panel10.Location = new System.Drawing.Point(5, 211);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(629, 168);
            this.panel10.TabIndex = 4;
            // 
            // dvgTKAD
            // 
            this.dvgTKAD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgTKAD.Location = new System.Drawing.Point(3, 3);
            this.dvgTKAD.Name = "dvgTKAD";
            this.dvgTKAD.Size = new System.Drawing.Size(623, 162);
            this.dvgTKAD.TabIndex = 0;
            // 
            // gbTTTKAD
            // 
            this.gbTTTKAD.Controls.Add(this.btDLMKTKAD);
            this.gbTTTKAD.Controls.Add(this.btSTKAD);
            this.gbTTTKAD.Controls.Add(this.btTTKAD);
            this.gbTTTKAD.Controls.Add(this.btXTKAD);
            this.gbTTTKAD.Controls.Add(this.tbTHTTKAD);
            this.gbTTTKAD.Controls.Add(this.lbTHTTKAD);
            this.gbTTTKAD.Controls.Add(this.btLMTKAD);
            this.gbTTTKAD.Controls.Add(this.tbTTKAD);
            this.gbTTTKAD.Controls.Add(this.lbTTKAD);
            this.gbTTTKAD.Location = new System.Drawing.Point(5, 85);
            this.gbTTTKAD.Name = "gbTTTKAD";
            this.gbTTTKAD.Size = new System.Drawing.Size(637, 120);
            this.gbTTTKAD.TabIndex = 0;
            this.gbTTTKAD.TabStop = false;
            this.gbTTTKAD.Text = "Thông tin chi tiết";
            // 
            // btDLMKTKAD
            // 
            this.btDLMKTKAD.Location = new System.Drawing.Point(502, 86);
            this.btDLMKTKAD.Name = "btDLMKTKAD";
            this.btDLMKTKAD.Size = new System.Drawing.Size(112, 27);
            this.btDLMKTKAD.TabIndex = 10;
            this.btDLMKTKAD.Text = "Đặt lại mật khẩu";
            this.btDLMKTKAD.UseVisualStyleBackColor = true;
            // 
            // btSTKAD
            // 
            this.btSTKAD.Location = new System.Drawing.Point(266, 86);
            this.btSTKAD.Name = "btSTKAD";
            this.btSTKAD.Size = new System.Drawing.Size(121, 27);
            this.btSTKAD.TabIndex = 8;
            this.btSTKAD.Text = "Sửa";
            this.btSTKAD.UseVisualStyleBackColor = true;
            // 
            // btTTKAD
            // 
            this.btTTKAD.Location = new System.Drawing.Point(146, 53);
            this.btTTKAD.Name = "btTTKAD";
            this.btTTKAD.Size = new System.Drawing.Size(121, 27);
            this.btTTKAD.TabIndex = 7;
            this.btTTKAD.Text = "Thêm";
            this.btTTKAD.UseVisualStyleBackColor = true;
            // 
            // btXTKAD
            // 
            this.btXTKAD.Location = new System.Drawing.Point(384, 53);
            this.btXTKAD.Name = "btXTKAD";
            this.btXTKAD.Size = new System.Drawing.Size(121, 27);
            this.btXTKAD.TabIndex = 9;
            this.btXTKAD.Text = "Xóa";
            this.btXTKAD.UseVisualStyleBackColor = true;
            // 
            // tbTHTTKAD
            // 
            this.tbTHTTKAD.Location = new System.Drawing.Point(372, 27);
            this.tbTHTTKAD.Name = "tbTHTTKAD";
            this.tbTHTTKAD.Size = new System.Drawing.Size(147, 20);
            this.tbTHTTKAD.TabIndex = 5;
            // 
            // lbTHTTKAD
            // 
            this.lbTHTTKAD.Location = new System.Drawing.Point(288, 26);
            this.lbTHTTKAD.Name = "lbTHTTKAD";
            this.lbTHTTKAD.Size = new System.Drawing.Size(92, 20);
            this.lbTHTTKAD.TabIndex = 0;
            this.lbTHTTKAD.Text = "Tên hiển thị:";
            this.lbTHTTKAD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btLMTKAD
            // 
            this.btLMTKAD.Location = new System.Drawing.Point(29, 86);
            this.btLMTKAD.Name = "btLMTKAD";
            this.btLMTKAD.Size = new System.Drawing.Size(121, 27);
            this.btLMTKAD.TabIndex = 6;
            this.btLMTKAD.Text = "Làm mới";
            this.btLMTKAD.UseVisualStyleBackColor = true;
            // 
            // tbTTKAD
            // 
            this.tbTTKAD.Location = new System.Drawing.Point(100, 27);
            this.tbTTKAD.Name = "tbTTKAD";
            this.tbTTKAD.Size = new System.Drawing.Size(147, 20);
            this.tbTTKAD.TabIndex = 4;
            // 
            // lbTTKAD
            // 
            this.lbTTKAD.Location = new System.Drawing.Point(17, 26);
            this.lbTTKAD.Name = "lbTTKAD";
            this.lbTTKAD.Size = new System.Drawing.Size(103, 20);
            this.lbTTKAD.TabIndex = 0;
            this.lbTTKAD.Text = "Tên tài khoản:";
            this.lbTTKAD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gbTKTKAD
            // 
            this.gbTKTKAD.Controls.Add(this.btTKTKADAll);
            this.gbTKTKAD.Controls.Add(this.btTKTKAD);
            this.gbTKTKAD.Controls.Add(this.tbTKTKAD);
            this.gbTKTKAD.Controls.Add(this.lbTKTKAD);
            this.gbTKTKAD.Location = new System.Drawing.Point(5, 4);
            this.gbTKTKAD.Name = "gbTKTKAD";
            this.gbTKTKAD.Size = new System.Drawing.Size(637, 75);
            this.gbTKTKAD.TabIndex = 0;
            this.gbTKTKAD.TabStop = false;
            this.gbTKTKAD.Text = "Tìm kiếm tài khoản admin";
            // 
            // btTKTKADAll
            // 
            this.btTKTKADAll.Location = new System.Drawing.Point(494, 31);
            this.btTKTKADAll.Name = "btTKTKADAll";
            this.btTKTKADAll.Size = new System.Drawing.Size(80, 20);
            this.btTKTKADAll.TabIndex = 3;
            this.btTKTKADAll.Text = "Tất cả";
            this.btTKTKADAll.UseVisualStyleBackColor = true;
            // 
            // btTKTKAD
            // 
            this.btTKTKAD.Location = new System.Drawing.Point(371, 32);
            this.btTKTKAD.Name = "btTKTKAD";
            this.btTKTKAD.Size = new System.Drawing.Size(80, 20);
            this.btTKTKAD.TabIndex = 2;
            this.btTKTKAD.Text = "Tìm kiếm";
            this.btTKTKAD.UseVisualStyleBackColor = true;
            // 
            // tbTKTKAD
            // 
            this.tbTKTKAD.Location = new System.Drawing.Point(120, 32);
            this.tbTKTKAD.Name = "tbTKTKAD";
            this.tbTKTKAD.Size = new System.Drawing.Size(214, 20);
            this.tbTKTKAD.TabIndex = 1;
            // 
            // lbTKTKAD
            // 
            this.lbTKTKAD.Location = new System.Drawing.Point(15, 31);
            this.lbTKTKAD.Name = "lbTKTKAD";
            this.lbTKTKAD.Size = new System.Drawing.Size(99, 20);
            this.lbTKTKAD.TabIndex = 0;
            this.lbTKTKAD.Text = "Tên người dùng:";
            this.lbTKTKAD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FrmTaiKhoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 424);
            this.Controls.Add(this.tcQTTK);
            this.Name = "FrmTaiKhoan";
            this.Text = "FrmTaiKhoan";
            this.tcQTTK.ResumeLayout(false);
            this.tpTKGV.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKGV)).EndInit();
            this.gbTTTKGV.ResumeLayout(false);
            this.gbTTTKGV.PerformLayout();
            this.gbTKTKGV.ResumeLayout(false);
            this.gbTKTKGV.PerformLayout();
            this.tpTKNVQT.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKQT)).EndInit();
            this.gbTTTKQT.ResumeLayout(false);
            this.gbTTTKQT.PerformLayout();
            this.gbTKTKQT.ResumeLayout(false);
            this.gbTKTKQT.PerformLayout();
            this.tpTKAD.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgTKAD)).EndInit();
            this.gbTTTKAD.ResumeLayout(false);
            this.gbTTTKAD.PerformLayout();
            this.gbTKTKAD.ResumeLayout(false);
            this.gbTKTKAD.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcQTTK;
        private System.Windows.Forms.TabPage tpTKGV;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DataGridView dgvTKGV;
        private System.Windows.Forms.GroupBox gbTTTKGV;
        private System.Windows.Forms.Button btDLMKTKGV;
        private System.Windows.Forms.Button btSTKGV;
        private System.Windows.Forms.Button btTTKGV;
        private System.Windows.Forms.Button btXTKGV;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lbTHTTKGV;
        private System.Windows.Forms.Button btLMTKGV;
        private System.Windows.Forms.TextBox tbTTKGV;
        private System.Windows.Forms.Label lbTTKGV;
        private System.Windows.Forms.GroupBox gbTKTKGV;
        private System.Windows.Forms.Button btTKTKGVAll;
        private System.Windows.Forms.Button btTKTKGV;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbTKTKGV;
        private System.Windows.Forms.TabPage tpTKNVQT;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView dgvTKQT;
        private System.Windows.Forms.GroupBox gbTTTKQT;
        private System.Windows.Forms.Button btDLMKTKQT;
        private System.Windows.Forms.Button btSTKQT;
        private System.Windows.Forms.Button btTTKQT;
        private System.Windows.Forms.Button btXTKQT;
        private System.Windows.Forms.TextBox tbTHTTKQT;
        private System.Windows.Forms.Label lbTHTTKQT;
        private System.Windows.Forms.Button btLMTKQT;
        private System.Windows.Forms.TextBox tbTTKQT;
        private System.Windows.Forms.Label lbTTKQT;
        private System.Windows.Forms.GroupBox gbTKTKQT;
        private System.Windows.Forms.Button btTKTKQTAll;
        private System.Windows.Forms.Button btTKTKQT;
        private System.Windows.Forms.TextBox tbTKTKQT;
        private System.Windows.Forms.Label lbTKTKQT;
        private System.Windows.Forms.TabPage tpTKAD;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.DataGridView dvgTKAD;
        private System.Windows.Forms.GroupBox gbTTTKAD;
        private System.Windows.Forms.Button btDLMKTKAD;
        private System.Windows.Forms.Button btSTKAD;
        private System.Windows.Forms.Button btTTKAD;
        private System.Windows.Forms.Button btXTKAD;
        private System.Windows.Forms.TextBox tbTHTTKAD;
        private System.Windows.Forms.Label lbTHTTKAD;
        private System.Windows.Forms.Button btLMTKAD;
        private System.Windows.Forms.TextBox tbTTKAD;
        private System.Windows.Forms.Label lbTTKAD;
        private System.Windows.Forms.GroupBox gbTKTKAD;
        private System.Windows.Forms.Button btTKTKADAll;
        private System.Windows.Forms.Button btTKTKAD;
        private System.Windows.Forms.TextBox tbTKTKAD;
        private System.Windows.Forms.Label lbTKTKAD;
    }
}