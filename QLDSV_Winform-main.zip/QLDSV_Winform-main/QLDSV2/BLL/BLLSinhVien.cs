﻿using QLDSV2.DAL;
using QLDSV2.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLDSV2.BLL
{
    internal class BLLSinhVien
    {
        readonly DALSinhVien dALSinhVien = new DALSinhVien();
        readonly DALLopHanhChinh dALLopHanhChinh = new DALLopHanhChinh();

        private DTOSinhVien CreteDTOSinhVien(string _maSV, string _tenSV, string _ngaySinh, int _gioiTinh, string _diaChi, string _soDienThoai, string _email, string _maLop, bool isAdd = true)
        {
            if (_maSV.Equals("") || _tenSV.Equals("") || _ngaySinh.Equals("") || _gioiTinh == -1 || _diaChi.Equals("") || _soDienThoai.Equals("") || _email.Equals("") || _maLop.Equals(""))
            {
                MessageBox.Show("Thông tin sinh viên không được để trống", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            if (isAdd)
            {
                if (dALSinhVien.CheckMaSVTonTai(_maSV))
                {
                    MessageBox.Show("Mã sinh viên đã tồn tại", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }

                if (dALSinhVien.CheckEmailSVTonTai(_email))
                {
                    MessageBox.Show("Email sinh viên đã tồn tại", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
            }   
            if (!DateTime.TryParse(_ngaySinh, out DateTime __ngaySinh))
            {
                MessageBox.Show("Ngày sinh không hợp lệ", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            if (!_email.Contains("@gmail.com"))
            {
                MessageBox.Show("Email không hợp lệ", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            if (!dALLopHanhChinh.CheckMaLopHanhChinhTonTai(_maLop))
            {
                MessageBox.Show("Lớp hành chính không tồn tại", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

            DTOSinhVien newSinhVien = new DTOSinhVien()
            {
                MaSinhVien = _maSV,
                TenSinhVien = _tenSV,
                NgaySinh = __ngaySinh,
                GioiTinh = _gioiTinh,
                DiaChi = _diaChi,
                SoDienThoai = _soDienThoai,
                Email = _email,
                MaLopHanhChinh = _maLop
            };

            return newSinhVien;
        }

        public List<DTOSinhVien> GetAllSinhVien(string _tenSinhVien, string _maLop, string _maKhoa)
        {
            return dALSinhVien.GetAllSinhVien(_tenSinhVien, _maLop, _maKhoa);
        }

        public bool ThemSinhVien(string _maSV, string _tenSV, string _ngaySinh, int _gioiTinh, string _diaChi, string _soDienThoai, string _email, string _maLop)
        {
            DTOSinhVien newSinhVien = CreteDTOSinhVien(_maSV, _tenSV, _ngaySinh, _gioiTinh, _diaChi, _soDienThoai, _email, _maLop);

            if (newSinhVien == null) return false;

            return dALSinhVien.ThemSinhVien(newSinhVien);
        }
        
        public bool XoaSinhVien(string _maSV)
        {
            return dALSinhVien.XoaSinhVien(_maSV);
        }

        public bool SuaNhanVien(string _maSV, string _tenSV, string _ngaySinh, int _gioiTinh, string _diaChi, string _soDienThoai, string _email, string _maLop)
        {
            DTOSinhVien newSinhVien = CreteDTOSinhVien(_maSV, _tenSV, _ngaySinh, _gioiTinh, _diaChi, _soDienThoai, _email, _maLop, false);

            if (newSinhVien == null) return false;

            return dALSinhVien.SuaSinhVien(newSinhVien);
        }
    }
}
