﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLDSV2.DAL;

namespace QLDSV2.BLL
{
    public enum LoaiTaiKhoan
    {
        none = 0,
        GiangVien,
        NhanVienQuanTri,
        Admin
    }

    internal class BLLTaiKhoan
    {
        readonly DALTaiKhoan dALTaiKhoan = new DALTaiKhoan();

        public object ValidateTaiKhoan(string tenDangNhap, string matKhau)
        {
            var _admin = dALTaiKhoan.ValidateTaiKhoanAdmin(tenDangNhap, matKhau);
            if (_admin != null) return _admin;

            var _nhanVienQuanTri = dALTaiKhoan.ValidateTaiKhoanNhanVienQuanTri(tenDangNhap, matKhau);
            if (_nhanVienQuanTri != null) return _nhanVienQuanTri;

            var _giangVien = dALTaiKhoan.ValidateTaiKhoanGiangVien(tenDangNhap, matKhau);
            if (_giangVien != null) return _giangVien;

            return null;
        }
    }
}
