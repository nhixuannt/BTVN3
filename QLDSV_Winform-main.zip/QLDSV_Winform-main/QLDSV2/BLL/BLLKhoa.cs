﻿using QLDSV2.DAL;
using QLDSV2.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLDSV2.BLL
{
    internal class BLLKhoa
    {
        readonly DALKhoa dALKhoa = new DALKhoa();

        public List<DTOKhoa> GetAllKhoa()
        {
            return dALKhoa.GetAllKhoa();
        }
    }
}
