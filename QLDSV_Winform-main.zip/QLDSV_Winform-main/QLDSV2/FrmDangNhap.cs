﻿using QLDSV2.BLL;
using QLDSV2.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLDSV2
{
    public partial class FrmDangNhap : Form
    {

        public FrmDangNhap()
        {
            InitializeComponent();
        }

        private void btDangNhap_Click(object sender, EventArgs e)
        {
            BLLTaiKhoan bLLTaiKhoan = new BLLTaiKhoan();

            var tenDangNhap = tbTaiKhoan.Text.Trim();
            var matKhau = tbMatKhau.Text.Trim();

            var nguoiDung = bLLTaiKhoan.ValidateTaiKhoan(tenDangNhap, matKhau);
            if (nguoiDung != null)
            {
                LoadFrmQLDSV(nguoiDung);
            }
            else
            {
                MessageBox.Show("Kiểm tra tên và số tài khoản", "Thông báo", MessageBoxButtons.OKCancel);
            }
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fDangNhap_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát chương trình", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void LoadFrmQLDSV(object _nguoiDung)
        {
            FrmQLDSV formQLDSV = new FrmQLDSV(_nguoiDung);
            this.Hide();
            formQLDSV.ShowDialog();
            this.Show();
        }
    }
}
