﻿create database QLDSV
go

use QLDSV
go

--TaiKhoan
--SinhVien
--GiangVien
--LopHanhChinh
--LopTinchi
--MonHoc
--Khoa

create table Khoa(
	maKhoa int primary key,
	tenKhoa nvarchar(100) not null,
	namThanhLap date not null,
	soDienThoai nvarchar not null
)

go

create table MonHoc(
	maMonHoc int primary key,
	tenMonHoc nvarchar(100) not null,
	sotinChi int not null,
	maKhoa int not null,

	constraint FK_MonHoc_Khoa foreign key (maKhoa) references dbo.Khoa(maKhoa)
)

go

create table GiangVien(
	maGiangVien int primary key,
	tenGiangVien nvarchar(100) not null,
	ngaySinh date not null,
	gioiTinh int not null, --0 là nam, 1 là nữ
	diaChi nvarchar(100) not null,
	soDienThoai nvarchar not null,
	email varchar(100) not null,
	hocVi int not null, --0: Cử nhân, 1: ThS, 2: TS
	maKhoa int not null,

	constraint FK_GiangVien_Khoa foreign key (maKhoa) references dbo.Khoa(maKhoa),
)

go


create table LopHanhChinh(
	maLopHanhchinh int primary key,
	maGiaoVienChuNhiem int not null,
	maKhoa int not null, 
	namHoc date not null,

	constraint FK_LopHanhChinh_Khoa foreign key (maKhoa) references dbo.Khoa(maKhoa),
	constraint FK_LopHanhChinh_GiangVien foreign key (maGiaoVienChuNhiem) references dbo.GiangVien(maGiangVien)
)

go


create table LopHocPhan(
	maLopHocPhan int primary key,
	maMonHoc int not null,
	maGiangVien int not null,
	hocKy int not null, -- chỉ có học kỳ 1 và học kỳ 2
	namHoc date not null,

	constraint FK_LopTinChi_MonHoc foreign key (maMonHoc) references dbo.MonHoc(maMonHoc),
	constraint FK_LopTinChi_GiangVien foreign key (maGiangVien) references dbo.GiangVien(maGiangVien)
)
go

create table SinhVien(
	maSinhVien int primary key,
	tenSinhVien nvarchar(100) not null,
	ngaySinh date not null,
	gioiTinh int not null, --0 là nam, 1 là nữ
	diaChi nvarchar(100) not null,
	soDienThoai nvarchar not null,
	email varchar(100) not null,
	maLopHanhChinh int not null,

	constraint FK_SinhVien_LopHanhChinh foreign key (maLopHanhChinh) references dbo.LopHanhChinh(maLopHanhChinh),
)
go

create table BangDiem(
	maLopHocPhan int not null, 
	maSinhVien int not null,
	diemQuaTrinh float,
	diemCuoiKy float,
	diemTongKet float,

	constraint PK_BangDiem PRIMARY KEY (maLopHocPhan, maSinhVien),
	constraint FK_BangDiem_LopTinChi foreign key (maLopHocPhan) references dbo.LopHocPhan(maLopHocPhan),
	constraint FK_BangDiem_SinhVien foreign key (maSinhVien) references dbo.SinhVien(maSinhVien)
)
go

create table TaiKhoanGiangVien(
	tenDangNhap varchar(100) primary key,
	matKhau varchar(1000) not null default('1'),
	tenHienThi nvarchar(100) not null default(N'Người dùng giảng viên'),
	maGiangVien int not null,

	constraint FK_TaiKhoanGiangVien_GiangVien foreign key (maGiangVien) references dbo.GiangVien(maGiangVien)
)
go

create table TaiKhoanAdmin(
	tenDangNhap varchar(100) primary key,
	matKhau varchar(1000) not null default('1'),
	tenHienThi nvarchar(100) not null default(N'Người dùng Admin'),
)

create table TaiKhoanNhanVienQuanTri(
	tenDangNhap varchar(100) primary key,
	matKhau varchar(1000) not null default('1'),
	tenHienThi nvarchar(100) not null default(N'Người dùng nhân viên quản trị'),
)